package com.rms.LoginRMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.rms.LoginRMS.bean.Login;
import com.rms.LoginRMS.dao.LoginDao;

@RestController
public class LoginService {
	@Autowired
	LoginDao ldao;
	@GetMapping(value="/retrieve/{username}/{password}")
	public String retrieve(@PathVariable ("username") String username ,@PathVariable ("password") String password)
	{
	
	List<Login> usersList=ldao.findAll();
	int flag=0;
    for(Login user:usersList)
    {
    	
    	if(user.getUserName().equalsIgnoreCase(username)&&user.getPassword().equals(password))
    	{
    		flag=1;
    		System.out.println(user);
    		break;
    	}
    	
    }
    if(flag==1)
    {
    	return "Successfully logged in";
    }
    else
    	return "Invalid credentials";
}}
